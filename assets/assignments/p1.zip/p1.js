/* 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Title : Project 1 Sliding Block Puzzle
Author : 
Created : 
Modified : 
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
*/

// Add any other global variables you may need here.

/**
 * Creates all the tiles necessary.
 * @return undefined
 */
function createTiles(){
  // figure out what tile specific information you need to add
  
  // can add all of the tiles here dynamically (which is useful if you are going to make the number of rows and columns adjustable, however you can also just specify them fixed in the HTML)
}

/**
 * Example function that could get called when a tile is clicked.
 * @param Add whatever params you need!
 * @return Fill in what the function returns here!
 */
function tileClicked(){
  // check if the tile can move to the empty spot
  // if the tile can move, move the tile to the empty spot
}

/**
 * Shuffle up the tiles in the beginning of the game
 * @return
 */
function shuffleTiles(){

}

/**
 * When the page loads, create our puzzle
 */
window.onload = function () {
  // generate parameters for a random puzzle
  // create the tiles
  // shuffle the tiles
}
